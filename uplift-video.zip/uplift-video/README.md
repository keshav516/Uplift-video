# Uplift promo video (Remotion)

    npm install
    npm run dev      # live preview in Remotion Studio
    npm run render   # -> out/uplift.mp4 (1280x720, 30fps, ~46s)

- Copy/industries/URL: `src/content.ts`
- Scene order and timing: `src/Video.tsx`
- Colors / shared pieces: `src/ui.tsx`
- Logos live in `public/` (`icon.jpg`, `logo-full.jpg`)
