import React from 'react';
import {AbsoluteFill, interpolate, spring, useCurrentFrame, useVideoConfig} from 'remotion';
import {loadFont} from '@remotion/google-fonts/PlusJakartaSans';

export const {fontFamily} = loadFont('normal', {weights: ['500', '700', '800'], subsets: ['latin']});

export const C = {
  navy: '#07205A',
  ink: '#0B1B3F',
  green: '#00CF9E',
  teal: '#0A8C98',
  blue: '#1B5FB4',
  bg: '#F2F7FB',
  mute: '#9FB0C8',
  line: '#DCE6F2',
};

export const grad = `linear-gradient(90deg, ${C.blue}, ${C.teal} 45%, ${C.green})`;

export const shadow = '0 24px 60px rgba(7,32,90,0.13), 0 2px 6px rgba(7,32,90,0.06)';

export const usePop = (delay = 0, rise = 28) => {
  const f = useCurrentFrame();
  const {fps} = useVideoConfig();
  const s = spring({frame: f - delay, fps, config: {damping: 18, stiffness: 130}});
  return {
    s,
    style: {
      opacity: Math.min(1, Math.max(0, s * 1.6)),
      transform: `translateY(${(1 - s) * rise}px) scale(${0.94 + 0.06 * s})`,
    } as React.CSSProperties,
  };
};

export const Pop: React.FC<{delay?: number; rise?: number; style?: React.CSSProperties; children: React.ReactNode}> = ({
  delay = 0,
  rise,
  style,
  children,
}) => {
  const {style: st} = usePop(delay, rise);
  return <div style={{...style, ...st}}>{children}</div>;
};

/** Fades a scene in and out so cuts feel soft. */
export const Scene: React.FC<{duration: number; children: React.ReactNode}> = ({duration, children}) => {
  const f = useCurrentFrame();
  const opacity = interpolate(f, [0, 10, duration - 12, duration], [0, 1, 1, 0], {
    extrapolateLeft: 'clamp',
    extrapolateRight: 'clamp',
  });
  return <AbsoluteFill style={{opacity}}>{children}</AbsoluteFill>;
};

export const Hi: React.FC<{children: React.ReactNode; italic?: boolean}> = ({children, italic}) => (
  <span
    style={{
      background: grad,
      WebkitBackgroundClip: 'text',
      backgroundClip: 'text',
      color: 'transparent',
      fontStyle: italic ? 'italic' : 'normal',
      paddingRight: italic ? 6 : 0,
    }}
  >
    {children}
  </span>
);

/** Word-by-word headline. Wrap highlighted words as {text, hi:true}. */
export const Words: React.FC<{
  words: (string | {t: string; hi?: boolean; italic?: boolean})[];
  delay?: number;
  size?: number;
  style?: React.CSSProperties;
}> = ({words, delay = 0, size = 68, style}) => (
  <div
    style={{
      display: 'flex',
      flexWrap: 'wrap',
      justifyContent: 'center',
      gap: `0 ${size * 0.26}px`,
      fontFamily,
      fontWeight: 800,
      fontSize: size,
      letterSpacing: -size * 0.03,
      color: C.ink,
      lineHeight: 1.1,
      ...style,
    }}
  >
    {words.map((w, i) => {
      const o = typeof w === 'string' ? {t: w} : w;
      return (
        <Pop key={i} delay={delay + i * 5} rise={22}>
          {(o as any).hi ? <Hi italic={(o as any).italic}>{o.t}</Hi> : o.t}
        </Pop>
      );
    })}
  </div>
);

export const Card: React.FC<{style?: React.CSSProperties; children?: React.ReactNode}> = ({style, children}) => (
  <div style={{background: '#fff', borderRadius: 22, boxShadow: shadow, ...style}}>{children}</div>
);

export const Sk: React.FC<{w: number | string; h?: number; style?: React.CSSProperties}> = ({w, h = 10, style}) => (
  <div style={{width: w, height: h, borderRadius: h, background: C.line, ...style}} />
);

export const Stars: React.FC<{count?: number; size?: number; startFrame?: number}> = ({count = 5, size = 22, startFrame = 0}) => {
  const f = useCurrentFrame();
  return (
    <div style={{display: 'flex', gap: 3}}>
      {Array.from({length: count}).map((_, i) => {
        const on = interpolate(f, [startFrame + i * 5, startFrame + i * 5 + 8], [0, 1], {
          extrapolateLeft: 'clamp',
          extrapolateRight: 'clamp',
        });
        return (
          <svg key={i} width={size} height={size} viewBox="0 0 24 24" style={{transform: `scale(${0.6 + 0.4 * on})`}}>
            <path
              d="M12 2l3.1 6.6 7.2.9-5.3 5 1.4 7.1L12 18l-6.4 3.6L7 14.5 1.7 9.5l7.2-.9z"
              fill={on > 0.5 ? '#FFB400' : C.line}
            />
          </svg>
        );
      })}
    </div>
  );
};

export const Background: React.FC = () => {
  const f = useCurrentFrame();
  const blob = (x: number, y: number, size: number, color: string, ph: number): React.CSSProperties => ({
    position: 'absolute',
    left: x + Math.sin((f + ph) / 70) * 40,
    top: y + Math.cos((f + ph) / 90) * 30,
    width: size,
    height: size,
    borderRadius: '50%',
    background: color,
    filter: 'blur(90px)',
    opacity: 0.55,
  });
  return (
    <AbsoluteFill style={{background: C.bg}}>
      <div style={blob(820, -160, 560, 'rgba(0,207,158,0.35)', 0)} />
      <div style={blob(-180, 380, 560, 'rgba(27,95,180,0.28)', 120)} />
      <div style={blob(380, 520, 420, 'rgba(10,140,152,0.18)', 240)} />
    </AbsoluteFill>
  );
};
