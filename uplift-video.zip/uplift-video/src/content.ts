// Edit the copy here. Everything on screen comes from the site's metadata:
// "Uplift helps local businesses like restaurants, gyms, salons and clinics get discovered
//  online, look credible, and turn attention into enquiries through Google, Meta and local SEO."
export const CONTENT = {
  brand: 'Uplift',
  tagline: 'Rise Beyond.',
  url: 'upliftdigital.vercel.app',
  channels: ['Google', 'Meta', 'Local SEO', 'Maps'],
  industries: [
    {emoji: '🍽️', label: 'Restaurants'},
    {emoji: '🏋️', label: 'Gyms'},
    {emoji: '💇', label: 'Salons'},
    {emoji: '🩺', label: 'Clinics'},
  ],
};
