import React from 'react';
import {Composition} from 'remotion';
import {UpliftPromo, TOTAL_FRAMES} from './Video';

export const Root: React.FC = () => (
  <Composition
    id="UpliftPromo"
    component={UpliftPromo}
    durationInFrames={TOTAL_FRAMES}
    fps={30}
    width={1280}
    height={720}
  />
);
