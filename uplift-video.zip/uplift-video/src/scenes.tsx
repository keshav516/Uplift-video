import React from 'react';
import {AbsoluteFill, Img, interpolate, staticFile, useCurrentFrame} from 'remotion';
import {C, Card, Hi, Pop, Scene, Sk, Stars, Words, fontFamily, grad, shadow, usePop} from './ui';
import {CONTENT} from './content';

const clamp = {extrapolateLeft: 'clamp', extrapolateRight: 'clamp'} as const;
const ease = (t: number) => 1 - Math.pow(1 - t, 3);
const center: React.CSSProperties = {position: 'absolute', left: 0, right: 0, display: 'flex', justifyContent: 'center'};

/* ───────────── 1. HOOK: floating cards go soft, then the question ───────────── */
const MiniCard: React.FC<{kind: number}> = ({kind}) => {
  if (kind === 0)
    return (
      <div style={{padding: 18}}>
        <div style={{display: 'flex', gap: 10, alignItems: 'center'}}>
          <div style={{width: 34, height: 34, borderRadius: 10, background: grad}} />
          <div><Sk w={120} h={10} /><Sk w={80} h={8} style={{marginTop: 8}} /></div>
        </div>
        <div style={{marginTop: 16}}><Stars size={18} startFrame={5} /></div>
        <Sk w="90%" style={{marginTop: 14}} /><Sk w="60%" style={{marginTop: 8}} />
      </div>
    );
  if (kind === 1)
    return (
      <div style={{padding: 14}}>
        <div style={{height: 100, borderRadius: 14, background: `linear-gradient(135deg, ${C.green}, ${C.blue})`, opacity: 0.85}} />
        <Sk w="70%" style={{marginTop: 14}} />
      </div>
    );
  if (kind === 2)
    return (
      <div style={{padding: 18}}>
        <div style={{display: 'flex', alignItems: 'center', gap: 8, fontFamily, fontWeight: 700, fontSize: 15, color: C.navy}}>
          <span style={{width: 10, height: 10, borderRadius: 10, background: C.green}} /> New enquiry
        </div>
        <Sk w="85%" style={{marginTop: 16}} /><Sk w="55%" style={{marginTop: 8}} />
        <div style={{marginTop: 16, width: 90, height: 28, borderRadius: 14, background: C.navy}} />
      </div>
    );
  return (
    <div style={{padding: 18}}>
      <div style={{display: 'flex', gap: 10, alignItems: 'center'}}>
        <div style={{width: 34, height: 34, borderRadius: 34, background: C.line}} />
        <Sk w={100} />
      </div>
      <div style={{marginTop: 14}}><Stars size={18} startFrame={12} /></div>
      <Sk w="90%" style={{marginTop: 14}} /><Sk w="70%" style={{marginTop: 8}} />
    </div>
  );
};

export const SceneHook: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const spots = [
    {x: 90, y: 70, r: -4}, {x: 890, y: 60, r: 3}, {x: 110, y: 470, r: 3}, {x: 880, y: 450, r: -3},
  ];
  const blur = interpolate(f, [70, 100], [0, 7], clamp);
  const l1 = interpolate(f, [12, 28, 62, 76], [0, 1, 1, 0], clamp);
  const l2 = interpolate(f, [80, 96], [0, 1], clamp);
  return (
    <Scene duration={d}>
      {spots.map((p, i) => (
        <Pop key={i} delay={i * 7} style={{position: 'absolute', left: p.x, top: p.y + Math.sin((f + i * 40) / 38) * 10}}>
          <Card style={{width: 300, height: 170, transform: `rotate(${p.r}deg)`, filter: `blur(${blur}px)`}}>
            <MiniCard kind={i} />
          </Card>
        </Pop>
      ))}
      <div style={{...center, top: 290, opacity: l1}}>
        <Words words={['Great', 'local', 'business.']} size={60} />
      </div>
      <div style={{...center, top: 240, opacity: l2, flexDirection: 'column', alignItems: 'center'}}>
        <Words words={['But', 'does', 'anyone']} delay={80} size={58} />
        <div style={{marginTop: 8}}>
          <Words words={[{t: 'find you?', hi: true, italic: true}]} delay={96} size={110} />
        </div>
      </div>
    </Scene>
  );
};

/* ───────────── 2. LOGO REVEAL ───────────── */
export const SceneLogo: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const wipe = ease(interpolate(f, [8, 50], [0, 1], clamp));
  const sc = 0.92 + 0.08 * wipe;
  return (
    <Scene duration={d}>
      <div style={{...center, top: 20}}>
        <Img
          src={staticFile('logo-full.jpg')}
          style={{width: 1000, mixBlendMode: 'multiply', clipPath: `inset(0 ${(1 - wipe) * 100}% 0 0)`, transform: `scale(${sc})`}}
        />
      </div>
      <div style={{...center, top: 560}}>
        <Words words={[{t: CONTENT.tagline, hi: true}]} delay={62} size={56} />
      </div>
    </Scene>
  );
};

/* ───────────── 3. CHANNELS → HUB ───────────── */
export const SceneChannels: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const xs = CONTENT.channels.map((_, i) => 640 + (i - 1.5) * 240);
  const hub = usePop(60);
  return (
    <Scene duration={d}>
      <div style={{...center, top: 60}}>
        <Words words={['Get', {t: 'discovered.', hi: true}]} size={70} />
      </div>
      <svg width={1280} height={720} style={{position: 'absolute', inset: 0}}>
        {xs.map((x, i) => {
          const p = ease(interpolate(f, [34 + i * 6, 64 + i * 6], [0, 1], clamp));
          return (
            <path key={i} d={`M ${x} 262 C ${x} 380, 640 360, 640 470`} fill="none" stroke={C.teal}
              strokeWidth={3} strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
          );
        })}
      </svg>
      {CONTENT.channels.map((c, i) => (
        <Pop key={c} delay={14 + i * 6} style={{position: 'absolute', left: xs[i] - 90, top: 210, width: 180}}>
          <Card style={{height: 52, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily, fontWeight: 700, fontSize: 22, color: C.navy, borderRadius: 16}}>
            {c}
          </Card>
        </Pop>
      ))}
      <div style={{position: 'absolute', left: 640 - 60, top: 470, width: 120, height: 120, ...hub.style}}>
        <div style={{width: 120, height: 120, borderRadius: 30, overflow: 'hidden', background: '#fff', boxShadow: shadow}}>
          <Img src={staticFile('icon.jpg')} style={{width: '100%', height: '100%', objectFit: 'cover', transform: 'scale(1.55)'}} />
        </div>
      </div>
      <div style={{...center, top: 610}}>
        <Pop delay={80}><div style={{fontFamily, fontWeight: 700, fontSize: 24, color: C.navy}}>One team. Every place locals look.</div></Pop>
      </div>
    </Scene>
  );
};

/* ───────────── 4. GET FOUND (ranking climb) ───────────── */
export const SceneFound: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const typed = 'restaurants near me';
  const n = Math.floor(interpolate(f, [18, 52], [0, typed.length], clamp));
  const prog = ease(interpolate(f, [70, 112], [0, 1], clamp));
  const rows = [{name: 'Local Cafe'}, {name: 'Corner Bistro'}, {name: CONTENT.brand + ' Client', you: true}];
  const youPos = 2 - 2 * prog;
  const badge = usePop(116);
  return (
    <Scene duration={d}>
      <div style={{...center, top: 40}}>
        <Words words={['Get', {t: 'found.', hi: true}]} size={64} />
      </div>
      <Pop delay={6} style={{position: 'absolute', left: 320, top: 150, width: 640}}>
        <Card style={{height: 490, position: 'relative', overflow: 'hidden'}}>
          <div style={{position: 'absolute', left: 24, right: 24, top: 22, height: 52, borderRadius: 26, background: C.bg, border: `2px solid ${C.line}`, display: 'flex', alignItems: 'center', padding: '0 22px', fontFamily, fontWeight: 500, fontSize: 21, color: C.ink}}>
            🔍&nbsp; {typed.slice(0, n)}<span style={{opacity: f % 16 < 8 ? 1 : 0}}>|</span>
          </div>
          {rows.map((r, i) => {
            const pos = r.you ? youPos : i + prog;
            return (
              <div key={i} style={{position: 'absolute', left: 24, right: 24, top: 100 + pos * 120, height: 104, borderRadius: 18,
                background: r.you ? '#F0FFFA' : '#fff', border: `2px solid ${r.you ? C.green : C.line}`, display: 'flex', alignItems: 'center', gap: 18, padding: '0 20px',
                boxShadow: r.you ? '0 10px 30px rgba(0,207,158,0.25)' : 'none'}}>
                <div style={{width: 60, height: 60, borderRadius: 16, background: r.you ? grad : C.line}} />
                <div style={{flex: 1}}>
                  <div style={{fontFamily, fontWeight: 700, fontSize: 22, color: C.navy}}>{r.name}</div>
                  <div style={{marginTop: 8}}><Stars size={16} startFrame={999} /></div>
                </div>
                {r.you && f > 112 && (
                  <div style={{...badge.style, background: C.green, color: '#fff', fontFamily, fontWeight: 800, fontSize: 20, padding: '8px 16px', borderRadius: 14}}>#1</div>
                )}
              </div>
            );
          })}
        </Card>
      </Pop>
    </Scene>
  );
};

/* ───────────── 5. LOOK CREDIBLE ───────────── */
export const SceneCredible: React.FC<{d: number}> = ({d}) => (
  <Scene duration={d}>
    <div style={{...center, top: 70}}>
      <Words words={['Look', {t: 'credible.', hi: true}]} size={64} />
    </div>
    {[0, 1, 2].map((i) => (
      <Pop key={i} delay={14 + i * 12} style={{position: 'absolute', left: 130 + i * 360, top: 230, width: 320}}>
        <Card style={{padding: 26, height: 230}}>
          <div style={{display: 'flex', alignItems: 'center', gap: 14}}>
            <div style={{width: 48, height: 48, borderRadius: 48, background: i === 1 ? grad : C.line}} />
            <div><Sk w={120} h={12} /><Sk w={70} h={9} style={{marginTop: 9}} /></div>
          </div>
          <div style={{marginTop: 22}}><Stars size={28} startFrame={30 + i * 14} /></div>
          <Sk w="92%" style={{marginTop: 22}} /><Sk w="78%" style={{marginTop: 10}} /><Sk w="55%" style={{marginTop: 10}} />
        </Card>
      </Pop>
    ))}
    <div style={{...center, top: 520, gap: 16}}>
      {['Google Profile', 'Reviews', 'Website'].map((t, i) => (
        <Pop key={t} delay={84 + i * 8}>
          <div style={{fontFamily, fontWeight: 700, fontSize: 22, color: C.navy, background: '#fff', borderRadius: 30, padding: '12px 26px', boxShadow: shadow}}>
            <span style={{color: C.green}}>✓</span> {t}
          </div>
        </Pop>
      ))}
    </div>
  </Scene>
);

/* ───────────── 6. TURN ATTENTION INTO ENQUIRIES ───────────── */
export const SceneEnquiries: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const stages = ['Views', 'Clicks', 'Enquiries'];
  const xs = [310, 640, 970];
  return (
    <Scene duration={d}>
      <div style={{...center, top: 50}}>
        <Words words={['Turn', 'attention', 'into', {t: 'enquiries.', hi: true}]} size={58} />
      </div>
      <svg width={1280} height={720} style={{position: 'absolute', inset: 0}}>
        {[0, 1].map((i) => {
          const p = interpolate(f, [34 + i * 22, 56 + i * 22], [0, 1], clamp);
          return <line key={i} x1={xs[i] + 80} y1={250} x2={xs[i + 1] - 80} y2={250} stroke={C.teal} strokeWidth={3}
            strokeLinecap="round" pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />;
        })}
      </svg>
      {stages.map((s, i) => {
        const last = i === 2;
        const glow = last ? interpolate(f, [80, 100], [0, 1], clamp) : 0;
        return (
          <Pop key={s} delay={18 + i * 18} style={{position: 'absolute', left: xs[i] - 80, top: 210, width: 160}}>
            <div style={{height: 80, borderRadius: 24, background: last && glow > 0.5 ? grad : '#fff', color: last && glow > 0.5 ? '#fff' : C.navy,
              boxShadow: last ? `0 0 ${50 * glow}px rgba(0,207,158,${0.6 * glow}), ${shadow}` : shadow,
              display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily, fontWeight: 800, fontSize: 26}}>{s}</div>
          </Pop>
        );
      })}
      {[0, 1, 2].map((i) => (
        <Pop key={i} delay={92 + i * 14} rise={40} style={{position: 'absolute', left: 250 + i * 270, top: 380 + (i % 2) * 40, width: 250}}>
          <Card style={{padding: 20, height: 130}}>
            <div style={{display: 'flex', alignItems: 'center', gap: 8, fontFamily, fontWeight: 700, fontSize: 17, color: C.navy}}>
              <span style={{width: 10, height: 10, borderRadius: 10, background: C.green}} /> New enquiry
            </div>
            <Sk w="85%" style={{marginTop: 18}} /><Sk w="60%" style={{marginTop: 10}} />
          </Card>
        </Pop>
      ))}
    </Scene>
  );
};

/* ───────────── 7. INDUSTRIES ───────────── */
export const SceneIndustries: React.FC<{d: number}> = ({d}) => (
  <Scene duration={d}>
    <div style={{...center, top: 70}}>
      <Words words={['Built', 'for', {t: 'local', hi: true}, 'businesses.']} size={60} />
    </div>
    {CONTENT.industries.map((it, i) => {
      const col = i % 2, row = Math.floor(i / 2);
      return (
        <Pop key={it.label} delay={18 + i * 10} style={{position: 'absolute', left: 250 + col * 410, top: 230 + row * 200, width: 370}}>
          <Card style={{height: 160, display: 'flex', alignItems: 'center', gap: 24, padding: '0 36px'}}>
            <div style={{fontSize: 64}}>{it.emoji}</div>
            <div style={{fontFamily, fontWeight: 800, fontSize: 34, color: C.navy}}>{it.label}</div>
          </Card>
        </Pop>
      );
    })}
  </Scene>
);

/* ───────────── 8. WE FIX IT (growth line) ───────────── */
export const SceneFix: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const a = interpolate(f, [0, 10, 40, 52], [0, 1, 1, 0], clamp);
  const b = interpolate(f, [52, 64], [0, 1], clamp);
  const p = ease(interpolate(f, [50, 105], [0, 1], clamp));
  const tag = usePop(100);
  const pts = '0,280 120,268 230,276 340,205 450,218 570,140 690,112 800,30';
  return (
    <Scene duration={d}>
      <div style={{...center, top: 90, opacity: a}}>
        <Words words={['Invisible', 'online?']} size={80} />
      </div>
      <div style={{...center, top: 90, opacity: b}}>
        <Words words={['We', {t: 'lift', hi: true}, 'it.']} delay={52} size={80} />
      </div>
      <svg width={800} height={300} viewBox="0 0 800 300" style={{position: 'absolute', left: 240, top: 300, overflow: 'visible'}}>
        <defs>
          <linearGradient id="g" x1="0" x2="1"><stop offset="0" stopColor={C.blue} /><stop offset="1" stopColor={C.green} /></linearGradient>
        </defs>
        <polyline points={pts} fill="none" stroke="url(#g)" strokeWidth={7} strokeLinecap="round" strokeLinejoin="round"
          pathLength={1} strokeDasharray={1} strokeDashoffset={1 - p} />
      </svg>
      <div style={{position: 'absolute', left: 1040 - 70, top: 262, ...tag.style}}>
        <div style={{background: C.green, color: '#fff', fontFamily, fontWeight: 800, fontSize: 18, padding: '7px 16px', borderRadius: 10, letterSpacing: 1.5}}>RISE BEYOND</div>
      </div>
    </Scene>
  );
};

/* ───────────── 9. END CARD ───────────── */
export const SceneEnd: React.FC<{d: number}> = ({d}) => {
  const f = useCurrentFrame();
  const sc = 0.94 + 0.06 * ease(interpolate(f, [0, 30], [0, 1], clamp));
  const o = interpolate(f, [0, 20], [0, 1], clamp);
  return (
    <AbsoluteFill>
      <div style={{...center, top: 10, opacity: o}}>
        <Img src={staticFile('logo-full.jpg')} style={{width: 1000, mixBlendMode: 'multiply', transform: `scale(${sc})`}} />
      </div>
      <div style={{...center, top: 570}}>
        <Pop delay={24}>
          <div style={{fontFamily, fontWeight: 700, fontSize: 30, color: C.navy, background: '#fff', borderRadius: 40, padding: '14px 38px', boxShadow: shadow}}>
            <Hi>{CONTENT.url}</Hi>
          </div>
        </Pop>
      </div>
    </AbsoluteFill>
  );
};
