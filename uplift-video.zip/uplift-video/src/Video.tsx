import React from 'react';
import {AbsoluteFill, Sequence} from 'remotion';
import {Background} from './ui';
import {SceneHook, SceneLogo, SceneChannels, SceneFound, SceneCredible, SceneEnquiries, SceneIndustries, SceneFix, SceneEnd} from './scenes';

// 1280x720 @ 30fps, 46s — same size/length as the reference video.
const SCENES: [React.FC<{d: number}>, number][] = [
  [SceneHook, 150],
  [SceneLogo, 150],
  [SceneChannels, 180],
  [SceneFound, 180],
  [SceneCredible, 180],
  [SceneEnquiries, 180],
  [SceneIndustries, 150],
  [SceneFix, 120],
  [SceneEnd, 90],
];

export const TOTAL_FRAMES = SCENES.reduce((a, [, d]) => a + d, 0); // 1380

export const UpliftPromo: React.FC = () => {
  let from = 0;
  return (
    <AbsoluteFill>
      <Background />
      {SCENES.map(([S, d], i) => {
        const start = from;
        from += d;
        return (
          <Sequence key={i} from={start} durationInFrames={d}>
            <S d={d} />
          </Sequence>
        );
      })}
    </AbsoluteFill>
  );
};
